from PIL import Image
import glob
import os

path = "C:/Users/jihad/Documents/new_dataset/data/data_set_20211222/voc_format_dataset20211222/voc_format_dataset20211222/data_dataset_voc/SegmentationClassPNG/"
lst_imgs = [i for i in glob.glob(path+"*.png")]

square_px = 840
for i in lst_imgs:
    
    img = Image.open(i)
    
    width, height = img.size
    img = img.crop(((width/2)-(height/2), 0, (width/2)+(height/2), height))
    #img = img.resize((square_px, square_px), Image.NEAREST)
    img.save(i)
    '''
    p_palette = img.getpalette()
    print ("saved :", p_palette)
    '''
