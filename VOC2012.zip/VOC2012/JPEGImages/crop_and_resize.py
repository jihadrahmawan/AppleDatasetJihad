from PIL import Image
import glob
import os

path = "C:/Users/jihad/Documents/data_set_20211222/voc_format_dataset20211222/voc_format_dataset20211222/data_dataset_voc/JPEGImages/"
lst_imgs = [i for i in glob.glob(path+"*.jpg")]

square_px = 512
for i in lst_imgs:
    print (i[125:146])
    
    # img = Image.open(i)
    
    # width, height = img.size
    # img = img.crop(((width/2)-(height/2), 0, (width/2)+(height/2), height))
    # #img = img.resize((square_px, square_px), Image.NEAREST)
    # img.save(i)
    '''
    p_palette = img.getpalette()
    print ("saved :", p_palette)
    '''
